"""Constants for scheduler."""
DAY = "day"
DAYS = f"{DAY}s"
HOUR = "hour"
HOURS = f"{HOUR}s"
MINUTE = "minute"
MINUTES = f"{MINUTE}s"
SECOND = "second"
SECONDS = f"{SECOND}s"

EVERY = "every"
UNIT = "unit"
TRIGGER = "trigger"
CRON = "cron"

JOB_SPLIT_CHAR = "."

# As per provided by Apscheduler.
# DO NOT CHANGE THESE
STATE_STOPPED = 0
STATE_RUNNING = 1
STATE_PAUSED = 2
