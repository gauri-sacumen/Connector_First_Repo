"""Schedule the jobs and execute as per scheduled intervals."""
import importlib
from typing import Any
from typing import Callable
from typing import Dict

from apscheduler.schedulers.background import BackgroundScheduler
from sac_scheduler.constants import CRON
from sac_scheduler.constants import EVERY
from sac_scheduler.constants import JOB_SPLIT_CHAR
from sac_scheduler.constants import STATE_PAUSED
from sac_scheduler.constants import STATE_STOPPED
from sac_scheduler.constants import TRIGGER
from sac_scheduler.constants import UNIT


class Schedule:
    """Schdule the process to be run in the background.

    :param object: Inherits default python object
    :type object: object
    """

    _scheduler: Any = None

    def __init__(self) -> None:
        """Initialize the schduler demon in the background."""
        self._scheduler = BackgroundScheduler(daemon=True)

    @property
    def scheduler(self) -> Any:
        """Get scheduler.

        This can be any subclass inheritef from BaseScheduler
        like BackgroundScheduler, BlockingScheduler, etc.

        :return: Scheduler object
        :rtype: Any
        """
        return self._scheduler

    @scheduler.setter
    def scheduler(self, scheduler: Any) -> None:
        """Set Scheduler object.

        This can be any subclass inheritef from BaseScheduler
        like BackgroundScheduler, BlockingScheduler, etc.

        :param scheduler: Scheduler object to be set
        :type scheduler: Any
        """
        self._scheduler = scheduler

    def add_job_storage(self, name: str, job_store: str) -> None:
        """Add persistent job storage to the scheduler.

        :param name: Name of the job store
        :type name: str
        :param job_store: URL / location of the job store
        :type job_store: str
        """
        self._scheduler.add_jobstore(name, url=job_store)

    def add_executors(self, executor: Dict[str, Any]) -> None:
        """Add executors to the scheduled jobs.

        :param executor: Executors to be added
        :type executor: Dict[str, Any]
        """
        self._scheduler.add_executor(executor)

    def add_job_defaults(self, job_defaults: Dict[str, Any]) -> None:
        """Add job defaults to the scheduler.

        Job defaults include coalesce, and max_instances for job.

        :param job_defaults: Job defaults to be included in scheduler.
        :type job_defaults: Dict[str, Any]
        """
        self._scheduler.configure(job_default=job_defaults)

    def add_configurations(
        self,
        jobstores: Dict[str, Any],
        executors: Dict[str, Any],
        job_defaults: Dict[str, Any],
    ) -> None:
        """Add configurations to the scheduled jobs.

        Configurations includes jobstores, executors and job_defaults
        for the scheduled jobs

        :param jobstores: Job store to be used
        :type jobstores: Dict[str, Any]
        :param executors: Executors to be used
        :type executors: Dict[str, Any]
        :param job_defaults: Job default configurations to be used
        :type job_defaults: Dict[str, Any]
        """
        self._scheduler.configure(
            jobstores=jobstores, executors=executors, job_defaults=job_defaults
        )

    def add_jobs(self, jobs: Dict[str, Any]) -> None:
        """Add jobs to the scheduler from configurations.

        :param jobs: Jobs to be added to the scheduler
        :type jobs: Dict[str, Any]
        """
        for func_name, config in jobs.items():
            package_path, function = func_name.rsplit(JOB_SPLIT_CHAR, 1)
            module = importlib.import_module(package_path)
            func = getattr(module, function)

            kwargs = {}

            if EVERY in config:
                kwargs[config[UNIT]] = config[EVERY]
                del config[UNIT]
                del config[EVERY]

            if config[TRIGGER] == CRON:
                del config[UNIT]

            for key, value in config.items():
                kwargs[key] = value

            self._scheduler.add_job(func, **kwargs)

    def add_job(
        self, func: Callable[[Dict[str, Any]], Any], schedule: Dict[str, Any]
    ) -> None:
        """Add single job to the scheduler.

        :param function: Function to be called to schedule a single job
        :type function: object
        :param schedule: Schedule to be executed for the function
        :type schedule: Dict[str, Any]
        """
        self._scheduler.add_job(func, **schedule)

    def start(self) -> None:
        """Start processing scheduled jobs.

        It will also start configured executors & job stores
        before starting scheduled jobs.
        """
        self._scheduler.start()

    def shutdown(self) -> None:
        """Shutdown the scheduler with its executors and job processes."""
        self._scheduler.shutdown()

    def pause(self) -> None:
        """Pause job processing in the scheduler.

        This will prevent the scheduler from waking up to do
        job processing until resume() is called.

        It will not however stop any already running job processing.
        """
        self._scheduler.pause()

    def resume(self) -> None:
        """Resume job processing in the scheduler."""
        self._scheduler.resume()

    def is_running(self) -> bool:
        """Check if scheduler is running or not.

        :return: True if running, else False
        :rtype: bool
        """
        return bool(self._scheduler.running)  # OK

    def is_paused(self) -> bool:
        """Check if scheduler is paused.

        :return: True if paused, else False
        :rtype: bool
        """
        return STATE_PAUSED == int(self._scheduler.state)  # OK

    def is_stopped(self) -> bool:
        """Check if the scheduler is stopped.

        :return: True if stopped, else False
        :rtype: bool
        """
        return STATE_STOPPED == int(self._scheduler.state)  # OK

    def is_job_exists(self, job_id: str) -> bool:
        """Look for job if it exists in the jobstore.

        :param job_id: Joib id to be checked to exists in the job store
        :type job_id: str
        :return: True if job exists, else False
        :rtype: bool
        """
        job = self._scheduler.get_job(job_id)
        return job is not None

    def get_job(self, job_id: str) -> Any:
        """Get the job specified by job_id.

        If job exists, it will return job else it will return None

        :param job_id: Job identifier
        :type job_id: str
        :return: Job object / None
        :rtype: object/None
        """
        return self._scheduler.get_job(job_id)

    def reschedule(self, job_id: str, schedule: Dict[str, Any]) -> None:
        """Reschdule the given job with the new scheduled values provided.

        :param job_id: Job to be rescheduled
        :type job_id: str
        :param schedule: New schedule for the job
        :type schedule: dict
        """
        self._scheduler.reschedule_job(job_id, **schedule)

    def remove_job(self, job_id: str) -> None:
        """Remove job if it exists in the scheduler.

        :param job_id: Job to be removed
        :type job_id: str
        """
        if self.is_job_exists(job_id):
            self._scheduler.remove_job(job_id)
