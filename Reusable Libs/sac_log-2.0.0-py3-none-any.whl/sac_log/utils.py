"""Utility functions to be used by pylog module."""
import os
from configparser import ConfigParser
from pathlib import Path
from typing import Any, Dict, List


def to_dict(config: ConfigParser) -> Dict[str, Any]:
    """Convert a ConfigParser object into a dictionary.

    The resulting dictionary has sections as keys which point to a dict of the
    sections options as key => value pairs.
    """
    config_dict: Dict[str, Any] = {}
    for section in config.sections():
        config_dict[section] = {}
        for key, val in config.items(section):
            config_dict[section][key] = val
    return config_dict


def get_configurations(filename: str) -> Dict[str, Any]:
    """Get configurations from configuration file.

    :param filename: name of the configuration file
    :type filename: str
    :return: Configurations supplied in the file
    :rtype: Dict[str, Any]
    """
    config = ConfigParser()
    config.read(filename)
    return to_dict(config)


def is_true(value: str) -> bool:
    """Check if provided value is true or not.

    :param value: String containing either True or False as a string
    :type value: str
    :return: True if the value contains True else False
    :rtype: bool
    """
    return value.lower() == "true"


def is_multiple_handlers(handlers: str) -> bool:
    """Check whether the configurations has multiple handlers included.

    :param config: Dictionary containing all the configurations read from the config file
    :type config: Dict[str, Any]
    :return: True if multiple handlers required else False
    :rtype: bool
    """
    handlers_list: List[str] = handlers.split(',')
    return len(handlers_list) > 1


def create_dir(path: Any) -> bool:
    """Create directory if does not exists.

    This takes directory names and check if they exists in the order as present in the list.
    If any directory does not present, it will create it and all the subsequent directories as it's children.

    It accepts List[str] OR str type parameters.

    :param path: List of directory names
    :type path: Any
    :return: True if directory is created else False
    :rtype: bool
    """
    if isinstance(path, str):
        path = [path]
    path = Path(os.path.join(*path))
    path.mkdir(parents=True, exist_ok=True)
    return os.path.exists(str(path))


def touch(path: str) -> bool:
    """Touch the directory path.

    :param path: Directory path
    :type path: str
    :return: True if path is present and is writable, else False
    :rtype: bool
    """
    if not os.path.exists(path):
        create_dir(path)
    return os.access(path, os.W_OK)
