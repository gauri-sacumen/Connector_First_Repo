"""Log the messages to the log files with mulitple handlers.

This is a wrapper module around python logging module.
"""