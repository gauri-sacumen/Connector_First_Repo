"""Queue to maintain metrics (MetricsQueue)."""
from queue import Queue
from typing import Any

from sac_queue.base import BaseQueue


class MetricsQueue(BaseQueue):
    """MetricsQueue class to store metrics data object to be used to generate metrics on scheduled time.

    This is FIFO queue and follows thread safety.

    Queue follows the Singleton design pattern hence object is not allowed to create with __init__ method,
    instead instance() method needs to be called which creates an object only if no object is created or
    else it will return the existing object

    :param object: Inherits base object class
    :type object: object
    :raises RuntimeError: raises exception is an object is created without instance() method
    :return: Metrics Queue Object
    :rtype: MetricsQueue
    """

    _instance: Any = None

    def __init__(self) -> None:  # pylint: disable=super-init-not-called
        """Initialize the MetricsQueue Object.

        :raises RuntimeError: This follows Singleton design pattern, hence creation of the instance should not be
        allowed via instance directly
        """
        raise RuntimeError("Call instance() instead")

    @classmethod
    def instance(cls) -> Any:
        """Instance method to create the instance of MetricsQueue class.

        This follows Singleton design pattern

        :return: MetricsQueue instance
        :rtype: MetricsQueue
        """
        if cls._instance is None:
            cls._instance = cls.__new__(cls)
            super(MetricsQueue, cls._instance).__init__(Queue())
        return cls._instance
