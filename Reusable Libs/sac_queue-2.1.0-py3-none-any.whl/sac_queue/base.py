"""Queue functionalities to be used as BaseQueue."""
from typing import Any, List


class BaseQueue:
    """IronQueue class to store the objects.

    This is FIFO queue and follows thread safety.

    Queue follows the Singleton design pattern hence object is not allowed to create with __init__ method,
    instead instance() method needs to be called which creates an object only if no object is created or
    else it will return the existing object

    :param object: Inherits base object class
    :type object: object
    :raises RuntimeError: raises exception is an object is created without instance() method
    :return: Queue Object
    :rtype: IronQueue
    """

    queue: Any = None

    def __init__(self, queue: Any) -> None:
        """Create an instance of a queue."""
        self.queue = queue

    def _read_one_element(self) -> Any:
        """Read one element from the queue.

        It will always read first element in the queue.

        :return: First element in the list
        :rtype: object
        """
        item = self.queue.get()
        self.queue.task_done()
        return item

    def _read_all(self) -> List[Any]:
        """Read all the elements from the queue.

        This uses lock over the queue so that no writes can happen during reading from the queue.
        It makes sure once the element is ready from the queue it will be removed permanently.

        Raises queue.Empty exception is queue is empty

        :return: List of elements read from the queue.
        :rtype: list

        """
        element_list = []
        while self.queue.qsize() > 0:
            item = self.queue.get()
            self.queue.task_done()
            element_list.append(item)

        return element_list

    def length(self) -> int:
        """Get the length of the queue, i.e., total number of elements currently present in the queue.

        :return: Number of elements in the queue
        :rtype: int
        """
        return int(self.queue.qsize())

    def add_to_queue(self, element: Any) -> None:
        """Add element to the queue.

        This uses locks over the queue so no read or other writes can happen during put process.

        Raises queue.Full exception if queue is full

        :param element: An object to be inserted in the queue
        :type element: object

        """
        self.queue.put(element)

    def read_from_queue(self, read_all: bool = True) -> Any:
        """Read elements from the queue.

        :param read_all: Status to check whether to read all the elements from the queue or one. Defaults to True.
        :type read_all: bool, optional
        :return:  List of elements or single lement from the queue
        :rtype: list / object

        """
        elements = None
        if read_all:
            elements = self._read_all()
        else:
            elements = self._read_one_element()
        return elements

    def clear(self) -> None:
        """Clear the queue.

        :raises ValueError: Task done is called too many times.
        """
        with self.queue.mutex:
            unfinished = self.queue.unfinished_tasks - len(self.queue)
            if unfinished <= 0:
                if unfinished < 0:
                    raise ValueError('The task_done() called too many times.')
                self.queue.all_tasks_done.notify_all()
            self.queue.unfinished_tasks = unfinished
            self.queue.queue.clear()
            self.queue.not_full.notify_all()
