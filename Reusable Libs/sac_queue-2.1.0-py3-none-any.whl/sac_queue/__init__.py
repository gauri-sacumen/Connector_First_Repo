"""Queues to be used for sharing data in between multiple queues.

Singleton implementaiton of queue with thread safety to maintain common
storage between multiple processes which includes:

1. Scheduled processes
2. kafka producer and consumer threads
3. Flask application process

This includes three queues:
1. Metrics Queue
2. Data Queue
3. Log Queue
"""
