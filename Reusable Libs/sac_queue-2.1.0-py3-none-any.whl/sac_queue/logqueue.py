"""Queue to maintain logs (LogQueue)."""
from queue import Queue
from typing import Any

from sac_queue.base import BaseQueue


class LogQueue(BaseQueue):
    """LogQueue class to store metrics data object to be used to store log on scheduled time.

    This is FIFO queue and follows thread safety.

    Queue follows the Singleton design pattern hence object is not allowed to create with __init__ method,
    instead instance() method needs to be called which creates an object only if no object is created or
    else it will return the existing object

    :param object: Inherits base object class
    :type object: object
    :raises RuntimeError: raises exception is an object is created without instance() method
    :return: Log Queue Object
    :rtype: LogQueue
    """

    _instance: Any = None

    def __init__(self) -> None:  # pylint: disable=super-init-not-called
        """Initialize the LogQueue object.

        :raises RuntimeError: This follows Singleton design pattern, hence creation of the instance should not be
        allowed via instance directly
        """
        raise RuntimeError("Call instance() instead")

    @classmethod
    def instance(cls) -> Any:
        """Instance method to create the instance of LogQueue class.

        This follows Singleton design pattern

        :return: LogQueue instance
        :rtype: LogQueue

        """
        if cls._instance is None:
            cls._instance = cls.__new__(cls)
            super(LogQueue, cls._instance).__init__(Queue())
        return cls._instance
