"""Certify the configurations by validating the fields and their types."""
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from sac_configurations.constants.chars import ARE_STR
from sac_configurations.constants.chars import COMMA_STR
from sac_configurations.constants.chars import EMPTY_STR
from sac_configurations.constants.chars import IS_STR
from sac_configurations.constants.chars import SPACE_STR
from sac_configurations.constants.general import SECTIONS
from sac_configurations.constants.messages import DATA_TYPE_MISMATCH
from sac_configurations.constants.messages import INVLAID_DATATYPE
from sac_configurations.constants.messages import MISSING_CONFIGS
from sac_configurations.constants.messages import MISSING_SECTIONS
from sac_configurations.constants.schema import DTYPE_BOOL
from sac_configurations.constants.schema import DTYPE_FLOAT
from sac_configurations.constants.schema import DTYPE_INT
from sac_configurations.constants.schema import DTYPE_IP
from sac_configurations.constants.schema import DTYPE_STRING
from sac_configurations.constants.schema import DTYPE_URL
from sac_configurations.context.schema import Schema
from sac_configurations.exceptions.base import ConfigurationsError
from sac_configurations.exceptions.input import MissingConfigsError
from sac_configurations.utils.validators import is_valid_ip_address
from sac_configurations.utils.validators import is_valid_url


class CertifyConfigurations:
    """Certify configuraitons object class.

    :param object: Inherits default object class
    :type object: class
    """

    def __init__(self, schema: Schema) -> None:
        """Verificaiton object initialiser.

        :param schema: Schema object for verification
        :type schema: Schema
        """
        self._schema = schema

    @property
    def schema(self) -> Schema:
        """Getter for schema property.

        :return: Schema object
        :rtype: Schema
        """
        return self._schema

    @schema.setter
    def schema(self, schema: Schema) -> None:
        """Setter for schema property.

        :param schema: Schema object to be set to schema
        :type schema: Schema
        """
        self._schema = schema

    def get_data_type(
        self, section: str, field: str, configs: Dict[str, Dict[str, str]]
    ) -> Tuple[str, Any]:
        """Get the data type of the field confgurations is correct.

        :param section: Section of the configuration
        :type section: str
        :param field: Option/Field of the configuration section
        :type field: str
        :param configs: Provided Configurations
        :type configs: Dict[str, Dict[str, str]]
        :return: Required configuration and it's class
        :rtype: Tuple[str, Any]
        """
        # Data type dictionary mapping the data type key with it's
        # respective class
        dtype_dict = {
            DTYPE_BOOL: bool,
            DTYPE_FLOAT: float,
            DTYPE_INT: int,
            DTYPE_STRING: str,
            DTYPE_URL: str,
            DTYPE_IP: str,
        }
        # Default value dictionary for each primitive data types
        default = {
            DTYPE_BOOL: False,
            DTYPE_FLOAT: 0.0,
            DTYPE_INT: 0,
            DTYPE_STRING: EMPTY_STR,
        }

        # Get the data type of the field in the section
        dtype = self.schema.get_dtype(section, field)

        if configs[section][field] is None and dtype in default.keys():
            configs[section][field] = default[dtype]  # type: ignore
        dtype_class = dtype_dict.get(dtype, None)

        return dtype, dtype_class

    def get_missing_sections(self, configs: Dict[str, Any]) -> List[str]:
        """Get missing sections in the configurations.

        :param configs: Configurations from which to get the secitons provided
        :type configs: Dict[str, Any]
        :return: List of sections absent in the configurations
        :rtype: List[str]
        """
        sections_required = set(self.schema.keys())
        sections_provided = set(configs.keys())
        return list(sections_required.difference(sections_provided))

    def assign_default(
        self, section: str, field: str, configs: Dict[str, Dict[str, str]]
    ) -> None:
        """Assign default value to the field in configurations.

        It assign the default value only if the field is empty

        :param section: Configuraitons section
        :type section: str
        :param field: Configuration field in section
        :type field: str
        :param configs: Configurations
        :type configs: Dict[str, Dict[str, str]]
        """
        # Get default value provided in schema
        default = self.schema.get_default(section, field)
        # Assign default value if field in section is empty in configurations
        if configs[section][field] is None and default is not None:
            configs[section][field] = default

    def check_data_type(
        self, section: str, field: str, configs: Dict[str, Any]
    ) -> None:
        """Check if data type of the configurations field is correct or not.

        :param section: Section in the configurations
        :type section: str
        :param field: Field in the configurations
        :type field: str
        :param configs: Configurations to be verified
        :type configs: Dict[str, Any]
        :raises MissingConfigsError: If the datatype of the field is wrong
        """
        # Check if the data type of the configurations field is wrong.
        dtype, dtype_class = self.get_data_type(section, field, configs)
        if not isinstance(configs[section][field], dtype_class):
            found = type(configs[section][field])
            raise MissingConfigsError(
                section.upper(),
                DATA_TYPE_MISMATCH.format(
                    config=field.upper(), required=dtype, found=found.__name__
                ),
            )

    def validate_data(self, section: str, field: str, value: Any) -> None:
        """Validate the value of the field w.r.t. data type supplied.

        It will check if the supplied value is of type dtype or not.
        If not, it will raise ConfigurationsError.

        :param section: Name of the section.
        :type section: str
        :param field: Field name
        :type field: str
        :param value: Value of the field
        :type value: Any
        :raises ConfigurationsError: Field is a primitive type but value is not
        :raises ConfigurationsError: Field is a URL but value is not valie URL
        :raises ConfigurationsError: Field is a IP address but value is not
        """
        # List of primitive data types
        primitive = [DTYPE_BOOL, DTYPE_FLOAT, DTYPE_INT, DTYPE_STRING]
        dtype_dict = {
            DTYPE_BOOL: bool,
            DTYPE_FLOAT: float,
            DTYPE_INT: int,
            DTYPE_STRING: str,
        }

        # Get the data type of the field in the section
        dtype = self.schema.get_dtype(section, field)

        # Primitive data type check
        primitive_check = dtype in primitive and not isinstance(
            value, dtype_dict[dtype]
        )
        # URL type check
        url_check = dtype == DTYPE_URL and not is_valid_url(value)
        # IP address check
        ip_check = dtype == DTYPE_IP and not is_valid_ip_address(value)

        if primitive_check or url_check or ip_check:
            msg = INVLAID_DATATYPE.format(
                field=field.upper(),
                value=value,
                dtype=dtype.upper(),
                section=section,  # pylint: disable=line-too-long
            )
            raise ConfigurationsError(field.upper(), msg)

    def verify_n_assign_default(self, conf: Dict[str, Any]) -> Dict[str, Any]:
        """Verify the configuration file for the necessary details configured.

        :param conf: Configurations dictionary
        :type conf: Dict[str, Any]
        :raises MissingConfigsError: Error representing missing required
            fields in the configurations
        :return: Configurations verified and with default values.
        :rtype: Dict[str, Any]
        """
        missing_sections = self.get_missing_sections(conf)
        if missing_sections:
            verb = ARE_STR if len(missing_sections) > 1 else IS_STR
            sections = f"{COMMA_STR}{SPACE_STR}".join(missing_sections)
            raise MissingConfigsError(
                SECTIONS.upper(),
                MISSING_SECTIONS.format(sections=sections, verb=verb),
            )

        section_list = conf.keys()

        for section in section_list:
            if not self.schema.is_section(section):
                # Section is missing in schema definition, ignore it
                continue
            for field in conf[section].keys():
                if not self.schema.is_field(section, field):
                    # Field is missing in schema definition, ignore it
                    continue
                # Assign default value if configuration is empty for
                # the field in section
                self.assign_default(section, field, conf)
                # Check if configurations field is required and
                # the configurations is not provided for the field
                if (
                    self.schema.is_required_field(section, field)
                    and conf[section][field] is None
                ):
                    message = MISSING_CONFIGS.format(config=field.upper())
                    raise MissingConfigsError(section.upper(), message)

                # Check if the data type of the configurations field is wrong.
                self.check_data_type(section, field, conf)

                # Validate the fields w.r.t. their type sepecified in schema
                self.validate_data(section, field, conf[section][field])

        return conf
