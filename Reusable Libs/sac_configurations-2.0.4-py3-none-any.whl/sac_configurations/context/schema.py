"""Schema defining sections, required, optional fields and assign default."""
from typing import Any
from typing import Dict
from typing import List

from sac_configurations.constants.messages import INVALID_FIELD_SCHEMA
from sac_configurations.constants.schema import SCHEMA_DEFAULT
from sac_configurations.constants.schema import SCHEMA_DTYPE
from sac_configurations.constants.schema import SCHEMA_REQUIRED
from sac_configurations.exceptions.schema import SchemaConfigsError
from sac_configurations.input.yaml import YamlConfig


class Schema:
    """Schema for loading configurations schema."""

    def __init__(self, path: str) -> None:
        """Initialize Schema Object.

        :param path: Schema file path
        :type path: str
        """
        yaml = YamlConfig()
        yaml.read([path])
        self.scheme: Dict[str, Any] = yaml.to_dict()

    @property
    def scheme(self) -> Dict[str, Any]:
        """Get the schema.

        :return: Schema Definition
        :rtype: Dict[str, Any]
        """
        return self._schema

    @scheme.setter
    def scheme(self, schm: Dict[str, Any]) -> None:
        """Set schema definition.

        :param schm: Schema definition to be set
        :type schm: Dict[str, Any]
        """
        self._schema = schm

    def keys(self) -> List[str]:
        """Get section keys from schema.

        :return: List of keys
        :rtype: List[str]
        """
        return list(self.scheme.keys())

    def is_section(self, section: str) -> bool:
        """Check if section is present with in the schema.

        :param section: Section to be checked
        :type section: str
        :return: True if present else False
        :rtype: bool
        """
        return section in self.scheme.keys()

    def is_field(self, section: str, field: str) -> bool:
        """Check if field exists in the schema.

        :param section: Section inside which to check for the field
        :type section: str
        :param field: Field name to be checked
        :type field: str
        :return: True if field exists in the schema else False
        :rtype: bool
        """
        field_in_keys = field in self.scheme.get(section).keys()  # type: ignore
        return self.is_section(section) and field_in_keys

    def get(self, section: str, field: Any = None) -> Dict[str, Any]:
        """Get section and it's field data from the schema.

        :param section: Section name to be fetched
        :type section: str
        :param field: Field tp fetch from the section, defaults to None
        :type field: Any, optional
        :return: Dictionary containing section details or
            field details if provided.
        :rtype: Dict[str, Any]
        """
        config: Dict = self.scheme.get(section, None)
        if config and field:
            config = config.get(field, None)
        return config

    def get_dtype(self, section: str, field: str) -> str:
        """Get data type of the field in section.

        :param section: Section name in which field is supposed to exists
        :type section: str
        :param field: Field whose data type is needed
        :type field: str
        :raises SchemaConfigsError: Schema configurations error raised when
            there is some issue field / section in the schema
        :return: Data Type of the field, if present else None
        :rtype: str
        """
        if not self.is_field(section, field):
            raise SchemaConfigsError(
                self.__class__.__name__,
                INVALID_FIELD_SCHEMA.format(field=field, section=section),
            )
        section_value = self.scheme.get(section)
        return section_value.get(field).get(SCHEMA_DTYPE)  # type: ignore

    def get_default(self, section: str, field: str) -> Any:
        """Get the default value of the field in the section.

        :param section: Section name in which field is supposed to exists
        :type section: str
        :param field: Field whose default value is needed
        :type field: str
        :raises SchemaConfigsError: Schema configurations error raised when
            there is some issue field / section in the schema
        :return: Default value specified by the schema
        :rtype: int / float / bool / str / None
        """
        if not self.is_field(section, field):
            raise SchemaConfigsError(
                self.__class__.__name__,
                INVALID_FIELD_SCHEMA.format(field=field, section=section),
            )
        section_value = self.scheme.get(section)
        return section_value.get(field).get(SCHEMA_DEFAULT)  # type: ignore

    def is_required_field(self, section: str, field: str) -> bool:
        """Check if field is required.

        :param section: Section name in which field is supposed to exists
        :type section: str
        :param field: Field to be checked whether it is required or not
        :type field: str
        :raises SchemaConfigsError: Schema configurations error raised when
            there is some issue field / section in the schema
        :return: True if it is a required field else False
        :rtype: bool
        """
        if not self.is_field(section, field):
            raise SchemaConfigsError(
                self.__class__.__name__,
                INVALID_FIELD_SCHEMA.format(field=field, section=section),
            )
        section_value = self.scheme.get(section)
        return section_value.get(field).get(SCHEMA_REQUIRED)  # type: ignore
