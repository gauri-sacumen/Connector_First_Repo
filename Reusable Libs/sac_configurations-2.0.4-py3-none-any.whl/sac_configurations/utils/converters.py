"""Converters to convert the input to another type."""
import locale

from sac_configurations.constants.chars import DOT_STR
from sac_configurations.constants.general import EN_US
from sac_configurations.constants.general import STRING_ON
from sac_configurations.constants.general import STRING_ONE
from sac_configurations.constants.general import STRING_TRUE
from sac_configurations.constants.general import STRING_YES
from sac_configurations.constants.general import UTF8


def convert_to_number(string: str) -> float:
    """Convert string to a number.

    :param string: String to be converted to a number
    :type string: str
    :return: String converted to float number
    :rtype: float
    """ 
    if locale.getlocale()[0] is None or locale.getlocale()[1] is None:
        current_local = f"{EN_US}.{UTF8}"
    else: 
        current_local = DOT_STR.join(locale.getlocale())

    locale.setlocale(locale.LC_ALL, current_local)
    return locale.atof(string)


def convert_to_bool(string: str) -> bool:
    """Convert string to a boolean.

    :param string: String to be converted to a boolean
    :type string: str
    :return: String converted to boolean value
    :rtype: bool
    """
    return string.lower() in [STRING_TRUE, STRING_YES, STRING_ON, STRING_ONE]
