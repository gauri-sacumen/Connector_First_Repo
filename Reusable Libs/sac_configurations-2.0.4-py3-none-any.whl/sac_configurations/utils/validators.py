"""Validate the input data adheres to certain type of value or not."""
import ipaddress
import os
import re

from sac_configurations.constants.chars import EMPTY_STR
from sac_configurations.constants.chars import NONE_STR
from sac_configurations.constants.chars import NULL_STR
from sac_configurations.constants.general import FILE_EXT_ENV
from sac_configurations.constants.general import NUMBER_REGEX
from sac_configurations.constants.general import STRING_FALSE
from sac_configurations.constants.general import STRING_NO
from sac_configurations.constants.general import STRING_OFF
from sac_configurations.constants.general import STRING_ON
from sac_configurations.constants.general import STRING_ONE
from sac_configurations.constants.general import STRING_TRUE
from sac_configurations.constants.general import STRING_YES
from sac_configurations.constants.general import STRING_ZERO
from sac_configurations.constants.regex import URL_REGEX


def is_number(string: str) -> bool:
    """Check if given string is a number or not.

    :param string: String to be checked for validation
    :type string: str
    :return: True if it's a number or else False
    :rtype: bool
    """
    return re.match(NUMBER_REGEX, string.strip()) is not None


def is_int(number: float) -> bool:
    """Check if given number is integer or not.

    :param number: Number to be checked for validation
    :type number: float
    :return: True if it's a integer or else False
    :rtype: bool
    """
    int_number = int(number)
    return number == int_number


def is_bool(string: str) -> bool:
    """Check if given string is boolean or not.

    :param string: String to be checked for validation
    :type string: str
    :return: True if it's a boolean or else False
    :rtype: bool
    """
    return string.strip().lower() in [
        STRING_TRUE,
        STRING_FALSE,
        STRING_YES,
        STRING_NO,
        STRING_ON,
        STRING_OFF,
        STRING_ONE,
        STRING_ZERO,
    ]


def is_none(string: str) -> bool:
    """Check if given string is None or not.

    :param string: String to be checked for validation
    :type string: str
    :return: True if it's a None or else False
    :rtype: bool
    """
    return string.strip().lower() in [NONE_STR, NULL_STR, EMPTY_STR]


def is_valid_filepath(path: str, ext: str = FILE_EXT_ENV) -> bool:
    """Check if given path is a valid or not.

    It checks whether supplied path is a valid file path with extension and
    parent directory of the file exists.

    :param path: Path to be verified
    :type path: str
    :param ext: Extension of the file, defaults to FILE_EXT_ENV
    :type ext: str, optional
    :return: True if it is a valid file path else False
    :rtype: bool
    """
    return path.lower().endswith(ext) and os.path.exists(os.path.dirname(path))


def is_valid_url(url: str) -> bool:
    """Check if given url is valid or not.

    It checks whether supplied url is valid url with domain name or ip address.

    This validator is based on the wonderful `URL validator of dperini`_.

    .. _URL validator of dperini:
        https://gist.github.com/dperini/729294

    Examples::
        >>> url('http://foobar.dk')
        True

        >>> url('ftp://foobar.dk')
        True

        >>> url('http://10.0.0.1')
        True

        >>> url('http://foobar.d')
        False

        >>> url('http://localhost:9005')
        True

    :param url: Url to be verified
    :type url: str
    :return: True if it is a valid url else False
    :rtype: bool
    """
    regex = re.compile(URL_REGEX, re.UNICODE | re.IGNORECASE)

    pattern = re.compile(regex)
    return pattern.match(url) is not None


def is_valid_ip_address(ip_address: str) -> bool:
    """Check if given ip address is valid or not.

    :param ip_address: IP address to be verified
    :type ip_address: str
    :return: True if it's valid ip address, else False
    :rtype: bool
    """
    status = True
    try:
        ipaddress.ip_address(ip_address)
    except ValueError:
        status = False
    return status
