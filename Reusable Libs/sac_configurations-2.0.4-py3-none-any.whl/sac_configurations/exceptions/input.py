"""Exceptions used during handling the input data."""
from sac_configurations.exceptions.base import ConfigurationsError


class MissingConfigsError(ConfigurationsError):
    """Exception to be raised when required configurations are missing.

    :param LookupError: Inherits Lookup Error
    :type LookupError: type
    """

    def __init__(self, category: str, message: str) -> None:
        """Initialise missing configuraitons error.

        :param category: Category of the error
        :type category: str
        :param message: Error message
        :type message: str
        """
        super().__init__(category, message)
        self.category = category
        self.message = message
