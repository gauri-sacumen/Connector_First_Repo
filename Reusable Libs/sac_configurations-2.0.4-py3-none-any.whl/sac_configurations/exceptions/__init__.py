"""Exceptions to raise and/or handle during configurations processing."""
