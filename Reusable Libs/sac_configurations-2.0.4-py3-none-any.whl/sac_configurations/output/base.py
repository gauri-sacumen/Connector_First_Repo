"""Base configurations output manager."""
from abc import abstractmethod
from typing import Any
from typing import Dict


class OutputConfig:
    """Base output configurations."""

    def __init__(self) -> None:
        """Initialize BaseConfig object."""
        self._path = None

    @property
    def path(self) -> Any:
        """Get the path for the output configurations.

        :return: Path of the configurations
        :rtype: Any
        """
        return self._path

    @path.setter
    def path(self, path: Any) -> None:
        """Set the path for the output configurations.

        :param path: Path of the configurations
        :type path: Any
        """
        self._path = path

    @abstractmethod
    def write(self, config: Dict) -> int:
        """Write the configurations in the file path provided.

        :param config: Configurations to be written
        :type config: Dict
        :return: count of records written in the output configurations media
        :rtype: int
        """
        pass
