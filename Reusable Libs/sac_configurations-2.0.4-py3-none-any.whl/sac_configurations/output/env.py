"""Configurations handler to write configurations in .env file."""
from typing import Dict

from sac_configurations.constants.chars import FILE_WRITE_STR
from sac_configurations.constants.chars import NEW_LINE_STR
from sac_configurations.constants.general import FILE_EXT_ENV
from sac_configurations.constants.messages import INVALID_ENV_FILEPATH
from sac_configurations.exceptions.output import OutputConfigsError
from sac_configurations.output.base import OutputConfig
from sac_configurations.utils.validators import is_valid_filepath


class EnvFile(OutputConfig):
    """EnvFile class to write the configurations to the .env file.

    :param OutputConfig: Inherits Base Output configurations
    :type OutputConfig: class
    """

    def __init__(self, path: str) -> None:
        """Initialize EnvFile object.

        :param path: .env file path
        :type path: str
        :raises OutputConfigsError: Output configurations error raised when
            there is some issue while writing configurations to the output media
        """
        super().__init__()
        if not is_valid_filepath(path, FILE_EXT_ENV):
            raise OutputConfigsError(
                self.__class__.__name__, INVALID_ENV_FILEPATH.format(path=path)
            )
        self.path = path

    def write(self, config: Dict) -> int:
        """Write the configurations to the .env file at the path provided.

        :param config: Configurations to be written to .env file
        :type config: Dict
        :raises OutputConfigsError: Output configurations error raised when
            there is some issue while writing configurations to the output media
        :return: Number of lines written to the .env file
        :rtype: int
        """
        count = 0
        config_list = []
        # Create a list of configurations to write
        for key, value in config.items():
            config_list.append(f"{key.upper()}={value}{NEW_LINE_STR}")
            count += 1

        file = None
        try:
            # Write the configurations to the .env file
            with open(self.path, FILE_WRITE_STR) as file:
                file.writelines(config_list)
        except Exception as err:
            msg = str(err)
            raise OutputConfigsError(self.__class__.__name__, msg) from err
        return count
