"""Configurations storage and handling.

The configurations can be stored in following medium:
1. .env file
2. json file
3. operating system environment
"""
