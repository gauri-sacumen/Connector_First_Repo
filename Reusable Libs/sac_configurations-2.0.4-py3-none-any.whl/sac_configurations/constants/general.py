"""General purpose constants."""
EN_US = "en_US"
UTF8 = "UTF-8"

# Regular expression for identifying number in a string
NUMBER_REGEX = r"^([0-9]+(?:\.[0-9]+)?)$"

# String representation of boolean values
STRING_TRUE = "true"
STRING_FALSE = "false"
STRING_YES = "yes"
STRING_NO = "no"
STRING_ON = "on"
STRING_OFF = "off"
STRING_ONE = "1"
STRING_ZERO = "0"

# Sections
SECTIONS = "sections"

# Default Section
DEFAULT = "default"

# File Extensions
FILE_EXT_JSON = ".json"
FILE_EXT_ENV = ".env"
