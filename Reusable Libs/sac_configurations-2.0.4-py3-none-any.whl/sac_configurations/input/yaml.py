"""Input configurations of type YAML."""
from typing import Any
from typing import Dict
from typing import List

import yaml  # type: ignore
from sac_configurations.constants.general import DEFAULT
from sac_configurations.input.base import InputConfig


class YamlConfig(InputConfig):
    """YAML configurations class to read yaml / yaml files.

    :param BaseInputConfig: Inherits Base Configurations class
    :type BaseInputConfig: class
    """

    def read(self, filenames: List[str]) -> None:
        """Read list of files provided and load in configurations.

        :param filenames: List of filenames
        :type filenames: List[str]
        """
        self.config: Dict[str, Any] = {}
        for filename in filenames:
            try:
                with open(filename) as file:
                    generator = yaml.load_all(file, yaml.SafeLoader)
                    for config in generator:
                        self.config.update(config)
            except FileNotFoundError:
                # Ignore file not found errors if the file does not exists.
                continue

    def sections(self) -> List[str]:
        """Get a list of section names from the configurations.

        :return: List of section names.
        :rtype: List[str]
        """
        return list(self.config.keys())

    def flatten(self) -> None:
        """Flatten the configurations into only one section."""
        self.flattened: Dict[str, Any] = {}
        config: Dict[str, Any] = {}
        for section, options in self.config.items():
            for key, value in options.items():
                config[f"{section.lower()}_{key.lower()}"] = value

        self.flattened[DEFAULT] = config

    def get(self, section: str, to_flat: bool = False) -> Dict[str, Any]:
        """Get configurations specified in a section.

        :param section: Configurations section
        :type section: str
        :param to_flat: Flag indicating whether to read from flattened
            configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations dictionary
        :rtype: Dict[str, Any]
        """
        config: Dict[str, Any] = {}
        parser = self.config if not to_flat else self.flattened
        if section in parser.keys():
            config = parser[section]

        return config

    def to_dict(self, to_flat: bool = False) -> Dict[str, Any]:
        """Convert configurations to dictionary.

        :param to_flat: Flag indicating whether to read from flattened
            configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations converted to dictionary
        :rtype: Dict[str, Any]
        """
        config: Dict[str, Any] = {}
        if not to_flat:
            config = self.config
        else:
            if self.flattened is None:
                self.flatten()  # type: ignore
            config = self.flattened.get(DEFAULT)  # type: ignore
        return config
