"""Base input configurations."""
import json
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import List


class InputConfig:
    """Base input configurations class.

    :param object: Inherits default parent
    :type object: class
    """

    def __init__(self) -> None:
        """Initialize BaseConfig object."""
        self._config = None
        self._flattened = None
        self._default = None

    @abstractmethod
    def read(self, filenames: List) -> None:
        """Read list of files provided and load in configurations.

        :param filenames: List of filenames
        :type filenames: List
        """
        pass

    @abstractmethod
    def sections(self) -> List[str]:
        """Get a list of section names from the configurations.

        :return: List of section names.
        :rtype: List[str]
        """
        pass

    @abstractmethod
    def flatten(self) -> None:
        """Flatten the configurations into only one section."""
        pass

    @abstractmethod
    def get(self, section: str, to_flat: bool = False) -> Dict:
        """Get configurations specified in a section.

        :param section: Configurations section
        :type section: str
        :param to_flat: Flag indicating whether to read from
            flattened configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations dictionary
        :rtype: Dict
        """
        pass

    @abstractmethod
    def to_dict(self, to_flat: bool = False) -> Dict:
        """Convert configurations to dictionary.

        :param to_flat: Flag indicating whether to read from
            flattened configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations converted to dictionary
        :rtype: Dict
        """
        pass

    @property
    def config(self) -> Any:
        """Get method for config property.

        :return: ConfigParser / Yaml / dict configuration
        :rtype: Any
        """
        return self._config

    @config.setter
    def config(self, cfg: Any) -> None:
        """Set method for config property.

        :param cfg: ConfigParser / Yaml / dict configuration
        :type cfg: Any
        """
        self._config = cfg

    @property
    def flattened(self) -> Any:
        """Get method for flatterned property.

        :return: ConfigParser / Yaml / dict configuration
        :rtype: Any
        """
        return self._flattened

    @flattened.setter
    def flattened(self, flttnd: Any) -> None:
        """Set method for flattened property.

        :param flttnd: ConfigParser / Yaml / dict configuration
        :type flttnd: Any
        """
        self._flattened = flttnd

    def to_json(self, to_flat: bool = False) -> str:
        """Convert configurations to json.

        :param to_flat: Flag indicating whether to read
            from flattened configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations in json format
        :rtype: str
        """
        config = self.to_dict(to_flat)
        return json.dumps(config)
