"""Module contains the helper function for the sac requests context."""
import requests  # type: ignore
from requests.packages.urllib3.util.retry import Retry  # type: ignore
from sac_requests.constants.chars import CONNECTOR
from sac_requests.constants.general import HTTP
from sac_requests.constants.general import HTTPS
from sac_requests.context.config import HttpConfig
from sac_requests.context.timeout import TimeoutHTTPAdapter


def set_request_session(config: HttpConfig) -> requests.Session:
    """Set request session with timeout and retry.

    :param config: Request configurations with retry and timeout configurations.
    :type config: HttpConfig
    :return: Request session object with retry and timeout configurations.
    :rtype: requests.Session
    """
    http = requests.Session()

    # Retry configurations
    retries = Retry(
        total=config.max_retry,
        backoff_factor=config.retry_interval,
        status_forcelist=config.status_force_list,
    )
    adapter = TimeoutHTTPAdapter(timeout=config.time_out, max_retries=retries)
    # Mount it for both http and https usage
    http.mount(f"{HTTPS}{CONNECTOR}", adapter)
    http.mount(f"{HTTP}{CONNECTOR}", adapter)

    return http
