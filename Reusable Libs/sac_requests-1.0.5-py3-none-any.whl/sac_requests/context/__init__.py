"""Http Request context used to prepare and send the requests over http."""
