"""Module contains the HttpRequest context to perform all the http request."""
import json
from typing import Any
from typing import Dict

import requests  # type: ignore
from requests.models import Response  # type: ignore
from requests.status_codes import codes as rsc  # type: ignore
from sac_requests.constants.general import AUTH
from sac_requests.constants.general import AUTHORIZATION
from sac_requests.constants.general import BASIC_AUTH
from sac_requests.constants.general import BEARER_TOKEN
from sac_requests.constants.general import DATA
from sac_requests.constants.general import GET
from sac_requests.constants.general import HEADERS
from sac_requests.constants.general import NO_AUTH
from sac_requests.constants.general import PARAMS
from sac_requests.constants.general import POST
from sac_requests.constants.general import URL
from sac_requests.constants.messages import BASIC_AUTH_PARAMS_MISSING
from sac_requests.constants.messages import CONNECTION_ERROR
from sac_requests.constants.messages import HTTP_ERROR
from sac_requests.constants.messages import MISSING_AUTH_TOKEN
from sac_requests.constants.messages import REQUEST_ERROR
from sac_requests.constants.messages import SSL_ERROR
from sac_requests.constants.messages import TIMEOUT_ERROR
from sac_requests.constants.messages import UNKNOWN_AUTH_TYPE
from sac_requests.context.config import HttpConfig
from sac_requests.context.endpoint import Endpoint
from sac_requests.context.headers import HttpHeaders
from sac_requests.context.session import set_request_session
from sac_requests.context.url import HttpURL
from sac_requests.exceptions.base import HttpRequestError
from sac_requests.exceptions.connection import HttpRequestConnectionError
from sac_requests.exceptions.timeout import HttpRequestTimeoutError


class HttpRequest:
    """Http Request wrapper to handle retries and timeouts."""

    def __init__(self, url: HttpURL, config: HttpConfig, headers: HttpHeaders, auth_type: str = NO_AUTH) -> None:
        """Initialise HTTP requests.

        :param url: Http Request URL
        :type url: str
        :param config: Configurations used in the request
        :type config: HttpConfig
        :param headers: Http Request Headers
        :type headers: HttpHeaders
        """
        if auth_type not in [NO_AUTH, BASIC_AUTH, BEARER_TOKEN]:
            raise ValueError(UNKNOWN_AUTH_TYPE)

        self._url = url
        self._auth_type = auth_type

        # Request Headers
        self._headers = headers

        # Request object
        self._session = set_request_session(config)

    @property
    def url(self) -> HttpURL:
        """Get URL for the http requests.

        :return: HTTP Request URL
        :rtype: URL
        """
        return self._url

    @url.setter
    def url(self, url: HttpURL) -> None:
        """Set URL for the http requests.

        :param url: HTTP Request URL
        :type url: URL
        """
        self._url = url

    @property
    def auth_type(self) -> str:
        """Get authentication type.

        :return: Authentication type
        :rtype: str
        """
        return self._auth_type

    @auth_type.setter
    def auth_type(self, auth_type_: str) -> None:
        """Set authnetication type.

        :param auth_type_: Authentication type
        :type auth_type_: str
        """
        self._auth_type = auth_type_

    @property
    def headers(self) -> HttpHeaders:
        """Get Http Request Headers.

        :return: Http Request Headers
        :rtype: HttpHeaders
        """
        return self._headers

    @headers.setter
    def headers(self, headers_: HttpHeaders) -> None:
        """Set Http Request Headers.

        :param headers_: Http Request Headers
        :type headers_: HttpHeaders
        """
        self._headers = headers_

    @property
    def session(self) -> requests.Session:
        """Get http request session object.

        :return: Request session object
        :rtype: requests.Session
        """
        return self._session

    @session.setter
    def session(self, http: requests.Session) -> None:
        """Set http/https session object.

        :param http: Request session object
        :type http: requests.Session
        """
        self._session = http

    def _validate_auth_headers(self, headers: Dict[str, Any], **kwargs: Any) -> None:  # pylint: disable=line-too-long
        """Validate the authentication parameters in headers.

        :param headers: Request headers supplied.
        :type headers: Dict[str, Any]
        :raises ValueError: If the Auth key does not exists in the parameters
        :raises ValueError: If the authentication token does not exists
            in the parameters.
        """
        if self.auth_type == BASIC_AUTH:
            if AUTH not in kwargs.keys():
                raise ValueError(BASIC_AUTH_PARAMS_MISSING)
        elif self.auth_type == BEARER_TOKEN:
            if AUTHORIZATION not in headers.keys():
                raise ValueError(MISSING_AUTH_TOKEN)
        else:
            # TODO: Other authentications methods will be handled.  # pylint: disable=fixme
            pass
    
    def _get_response_message(self, response: Response) -> str:
        """Get the message from the response object.

        :param response: Response received from the request
        :type response: Response
        :return: Response Message
        :rtype: str
        """
        message: str = ""
        try:
            content = response.json()
            message = json.dumps(content)
        except ValueError:
            """No need to process anything since the response is not in json."""
            pass
        return message

    def _send(self, method: str, **kwargs: Dict[str, Any]) -> Response:
        """Send request to the URL supplied over the method.

        :param method: Request method to be called, like get, post, etc.
        :type method: str
        :raises HttpRequestError: Http request error occured
        :raises HttpRequestConnectionError: Connection error occured
        :raises HttpRequestTimeoutError: Request timed out
        :raises HttpRequestError: SSL related error occcured
        :raises HttpRequestError: Other error occured while sending request.
        :return: Response recieved from the URL endpoint.
        :rtype: Response
        """
        response: Any = None
        try:
            _request = getattr(self.session, method)
            response = _request(**kwargs)
            self.close()

            # Assert that there were no errors
            response.raise_for_status()
        except requests.exceptions.HTTPError as err:
            content = self._get_response_message(response) if response is not None else ''
            err_msg = content if content else str(err)
            msg = HTTP_ERROR.format(url=kwargs[URL], msg=err_msg)
            ecd = err.response.status_code if err.response is not None else rsc.bad_request
            raise HttpRequestError(message=msg, errcode=ecd) from err
        except requests.exceptions.SSLError as err:
            msg = SSL_ERROR.format(url=kwargs[URL], msg=str(err))
            ecd = err.response.status_code if err.response is not None else rsc.bad_request
            raise HttpRequestError(message=msg, errcode=ecd) from err
        except requests.exceptions.ConnectionError as err:
            msg = CONNECTION_ERROR.format(url=kwargs[URL], msg=str(err))
            ecd = err.response.status_code if err.response is not None else rsc.bad_request
            raise HttpRequestConnectionError(msg, ecd) from err
        except requests.exceptions.Timeout as err:
            msg = TIMEOUT_ERROR.format(url=kwargs[URL], msg=str(err))
            ecd = err.response.status_code if err.response is not None else rsc.bad_request
            raise HttpRequestTimeoutError(msg, ecd) from err
        except requests.exceptions.RequestException as err:
            msg = REQUEST_ERROR.format(url=kwargs[URL], msg=str(err))
            ecd = err.response.status_code if err.response is not None else rsc.bad_request
            raise HttpRequestError(message=msg, errcode=ecd) from err
        except Exception as err:
            msg = REQUEST_ERROR.format(url=kwargs[URL], msg=str(err))
            ecd = requests.codes.bad_request
            raise HttpRequestError(message=msg, errcode=ecd) from err
        return response

    def post(self, endpoint: str, headers: Any = None, data: Any = None, params: Any = None, **kwargs: Any) -> Response:
        """Send post request with headers and data.

        :param endpoint: URL endpoint to which to send the request
        :type endpoint: str
        :param headers: Request headers, defaults to None
        :type headers: Any, optional
        :param data: Request Data, defaults to None
        :type data: Any, optional
        :param params: Request parameters, defaults to None
        :type params: Any, optional
        :return: Response received from the request
        :rtype: Response
        """
        # Get the Request URL.
        _url = self.url.prepare(endpoint=Endpoint(endpoint))

        # Set the Headers
        self.headers.update(headers)
        headers = self.headers.get()

        self._validate_auth_headers(headers, **kwargs)

        # Add the request key-value pairs to the dictionary
        kwargs[URL] = _url
        kwargs[HEADERS] = headers
        kwargs[DATA] = data
        kwargs[PARAMS] = params

        # Send the POST request
        response = self._send(POST, **kwargs)
        return response

    def get(self, endpoint: str, headers: Any = None, data: Any = None, params: Any = None, **kwargs: Any) -> Response:
        """Send get request with headers and query parameters.

        :param endpoint: URL endpoint to which to send the request
        :type endpoint: str
        :param headers: Request headers, defaults to None
        :type headers: Any, optional
        :param data: Request Data, defaults to None
        :type data: Any, optional
        :param params: Request parameters, defaults to None
        :type params: Any, optional
        :return: Response received from the request
        :rtype: Response
        """
        # Get the Request URL.
        _url = self.url.prepare(endpoint=Endpoint(endpoint))

        # Set the Headers
        self.headers.update(headers)
        headers = self.headers.get()

        self._validate_auth_headers(headers, **kwargs)

        # Add the request key-value pairs to the dictionary
        kwargs[URL] = _url
        kwargs[HEADERS] = headers
        kwargs[DATA] = data
        kwargs[PARAMS] = params

        # Send the GET request
        response = self._send(GET, **kwargs)
        return response

    def close(self) -> None:
        """Close http connection."""
        self.session.close()
