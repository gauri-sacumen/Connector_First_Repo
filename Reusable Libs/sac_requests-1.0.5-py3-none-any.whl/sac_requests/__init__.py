"""Request adaptor to help send requests to the external APIs over HTTP/HTTPS.

GOALS:

1. Sends request of types:
    1. Get
    2. Post
    3. Put
    4. Delete
    5. Head
    6. Patch

2. Performs authentications like:
    1. Basic Authentications
    2. Bearer Token Base Authentication
    3. Oauth 2.0 Authentication
    4. No Authentication

3. Performs retries in case of any network related issues.
    The number of retries and the gap between consecutive retries is
    user-configurable.
    If the number of retries is not supplied, it will take default 3 times.
"""
