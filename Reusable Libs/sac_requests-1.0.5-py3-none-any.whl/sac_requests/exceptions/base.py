"""Http Request error exceptions."""
import requests  # type: ignore
from requests.exceptions import RequestException  # type: ignore


class HttpRequestError(RequestException, ConnectionError):  # type: ignore
    """Exception to be raised when there is an error while sending a request.

    :param RequestException: Extensions Request Exception
    :type RequestException: type
    """

    def __init__(
        self, message: str, errcode: int = requests.codes.bad_request
    ) -> None:  # pylint: disable=line-too-long
        """Initialise HttpRequestError.

        :param message: Error message
        :type message: str
        :param errcode: Error Code, defaults to requests.codes.bad_request (400)
        :type errcode: int, optional
        """
        super().__init__()
        self.errcode = errcode
        self.message = message

    def __str__(self) -> str:
        """Represent error as string.

        :return: Http Reqyest error when called by str function
        :rtype: str
        """
        return f"{self.__class__.__name__} [{self.errcode}]: {self.message}"

    def __repr__(self) -> str:
        """Raw object representation of the Error.

        :return: Raw representation of the http request error.
        :rtype: str
        """
        error = "<{name} category={cat} msg={msg}>"
        return error.format(
            name=self.__class__.__name__, cat=self.errcode, msg=self.message
        )
