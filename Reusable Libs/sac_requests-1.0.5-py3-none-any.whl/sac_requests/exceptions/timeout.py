"""Http request timeout exception."""
from sac_requests.exceptions.base import HttpRequestError


class HttpRequestTimeoutError(
    HttpRequestError
):  # pylint: disable=too-few-public-methods
    """Request timeout can be raised when the request is timedout.

    :param TimeoutError: Inherits Timeout error
    :type TimeoutError: type
    :param HttpRequestError: Inherits HttpRequestError
    :type HttpRequestError: type
    """

    pass
