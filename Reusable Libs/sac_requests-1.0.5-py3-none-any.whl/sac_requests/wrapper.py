"""Http Request wrapper to wrap the request creation process."""
from typing import Any
from typing import Dict

from requests.models import Response  # type: ignore
from sac_requests.constants.general import DATA
from sac_requests.constants.general import ENDPOINT
from sac_requests.constants.general import GET
from sac_requests.constants.general import HEADERS
from sac_requests.constants.general import PARAMS
from sac_requests.context.config import HttpConfig
from sac_requests.context.headers import HttpHeaders
from sac_requests.context.request import HttpRequest
from sac_requests.context.url import HttpURL
from sac_requests.exceptions.base import HttpRequestError
from sac_requests.utils.general import get_url_components


class HttpRequestWrapper:
    """Http Request wrapper for generating a HttpRequest object."""

    def __init__(self, url: str, **kwargs: Dict[str, Any]) -> None:
        """Initialise the HttpWrapper object.

        It accepts parameters like:
        1. URL
        2. Headers (Request headers)
        3. Request configurations like:
            a. Max Retries
            b. Retry interval
            c. Request Timeout.

        :param url: URL to which to send the request
        :type url: str
        """
        # Get the headers
        headers = kwargs.get(HEADERS, {})
        if headers is None:
            headers = {}  # type: ignore
        self.headers = HttpHeaders(headers)

        # Get Http configurations.
        self.config = HttpConfig(**kwargs)

        # Set the protocol if it is not provided
        scheme, host, port, path = get_url_components(url)

        # Get endpoint
        self.endpoint = path

        # Get the URL
        self.url = HttpURL(protocol=scheme, host=host, port=port)

    def get(self) -> HttpRequest:
        """Get the Http Request object to be used to send the request.

        :return: Http request object
        :rtype: HttpRequest
        """
        return HttpRequest(self.url, self.config, self.headers)

    def send(self, method: str, endpoint: str = "", headers: Any = None, data: Any = None, params: Any = None, **kwargs: Any) -> Response:  # pylint: disable=too-many-arguments
        """Send request to the endpoint with parameters and data supplied.

        :param method: Http request method, e.g. get / post / etc.
        :type method: str
        :param endpoint: Endpoint to send requests to, defaults to ""
        :type endpoint: str, optional
        :param headers: Request headers, defaults to None
        :type headers: Any, optional
        :param data: Request data that needs to be sent, defaults to None
        :type data: Any, optional
        :param params: Request parameters, defaults to None
        :type params: Any, optional
        :raises ValueError: Request parameters are invalid
        :raises HttpRequestError: Some error occured during request processing.
        :return: Response received from the endpoint
        :rtype: Response
        """
        response: Any = None
        try:
            # Add the request key-value pairs to the dictionary
            kwargs[ENDPOINT] = endpoint if endpoint else self.endpoint
            kwargs[HEADERS] = headers
            kwargs[DATA] = data
            kwargs[PARAMS] = params

            # Get the request type
            request = getattr(self.get(), method, GET)
            # Send the request
            response = request(**kwargs)
        except ValueError as err:
            raise ValueError(str(err)) from err
        except HttpRequestError as err:
            raise err.__class__(message=err.message, errcode=err.errcode) from err  # pylint: disable=bad-exception-context

        return response
