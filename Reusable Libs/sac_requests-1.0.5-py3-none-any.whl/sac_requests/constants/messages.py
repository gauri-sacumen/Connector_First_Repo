"""Success and Error message constants."""
INVALID_HEADER_FORMAT = (
    "Invalid header format supplied. Request header must be a key-value pair."
)
BASIC_AUTH_PARAMS_MISSING = (
    "Basic Authentication Parameters (username, password) are missing"  # nosec
)
MISSING_AUTH_TOKEN = """Authorization token is missing in header"""  # nosec
UNKNOWN_AUTH_TYPE = "Unrecognised auth type supplied."


# Http error response messages
HTTP_ERROR = "Request to {url} failed with the message = {msg}."
CONNECTION_ERROR = "Connection to {url} resulted in error with message = {msg}"
TIMEOUT_ERROR = "Request to {url} is timed out with message = {msg}."
SSL_ERROR = "Request to {url} resulted in SSLError with message = {msg}."
REQUEST_ERROR = "Failed to send a request to {url} with message = {msg}."
