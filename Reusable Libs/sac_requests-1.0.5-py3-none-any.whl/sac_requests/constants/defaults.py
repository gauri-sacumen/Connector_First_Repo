"""Module contains the default value for variable used in sac request."""
from sac_requests.constants.general import NO_AUTH

DEFAULT_TIMEOUT = 5  # seconds
DEFAULT_MAX_RETRY = 3
DEFAULT_RETRY_INTERVAL = 1  # seconds
DEFAULT_STATUS_FORCE_LIST = [429, 500, 502, 503, 504]
DEFAULT_AUTH_TYPE = NO_AUTH
DEFAULT_HTTP_PORT = 80
DEFAULT_HTTPS_PORT = 443
