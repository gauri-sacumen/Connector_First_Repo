"""Constants used in the library."""
