"""Connect to telegraf server for saving metrics information."""
