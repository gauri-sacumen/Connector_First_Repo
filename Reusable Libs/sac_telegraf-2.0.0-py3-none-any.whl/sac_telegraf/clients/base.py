"""Base client to connect to telegraf.

This class provides common functionalities that can be used by all the telegraf clients.
"""
from abc import abstractmethod
from typing import Any, Dict

from sac_telegraf.constants import DEFAULT_HOST, DEFAULT_PORT
from sac_telegraf.dataformats.inputs.protocol import Line


class BaseClient:
    """Base class for telegraf client."""

    host: str = ''
    port: int = 0
    tags: Dict[str, Any] = {}

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, tags: Any = None) -> None:
        """Initialise the telegraf client.

        :param host: Telegraf host to connect, defaults to TELEGRAF_HOST
        :type host: str, optional
        :param port: Telegraf port to connect, defaults to TELEGRAF_PORT
        :type port: int, optional
        :param tags: Tags to include in telegraf, defaults to None
        :type tags: Any, optional
        """
        self.host = host
        self.port = port
        self.tags = tags or {}

    def metric(self, measurement: str, values: Dict[str, Any], tags: Any = None, timestamp: int = 0) -> Any:
        """Convert the provided data to line protocol and send to telegraf.

        Append global tags configured for the client to the tags given then
        converts the data into InfluxDB Line protocol and sends to to socket

        :param measurement: Telegraf measurement name
        :type measurement: str
        :param values: Dictionary containing metric key-value pairs
        :type values: dict
        :param tags: Tags to be added to metrics, defaults to None
        :type tags: Any, optional
        :param timestamp: Time at which the metric is recorded, defaults to None
        :type timestamp: str, optional
        :return: Number of bytes written to the telegraf
        :rtype: int
        """
        if not measurement or values in [None, {}]:
            # Don't try to send empty data
            return None

        if tags is None:
            tags = {}

        # Do a shallow merge of the metric tags and global tags
        all_tags = dict(self.tags, **tags)

        # Create a metric line from the input and then send it to socket
        line = Line(measurement, values, all_tags, timestamp)
        return self.send(line.to_line_protocol())

    @abstractmethod
    def send(self, data: str) -> Any:
        """Abstract send method to be implemented by each child class.

        :param data: String containing message to be sent to telegraf
        :type data: str
        :return: Number of bytes written to the socket / Success or Error code / None
        :rtype: Any
        """
        pass

    @abstractmethod
    def close(self) -> None:
        """Abstract close method to be implemented by each child class.

        This closes the connection with the client.
        """
        pass
