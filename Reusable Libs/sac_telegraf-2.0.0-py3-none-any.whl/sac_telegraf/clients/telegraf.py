"""Socket client to connect to telegraf."""
import socket
from typing import Any

from sac_telegraf.clients.base import BaseClient
from sac_telegraf.constants import DEFAULT_HOST, DEFAULT_PORT


class TelegrafClient(BaseClient):
    """Socket based Telegraf client."""

    _connection: Any = None

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, tags: Any = None) -> None:
        """Initialise socket Telegarf Client.

        :param host: Host of telegraf client. Defaults to HOST., defaults to TELEGRAF_HOST
        :type host: str, optional
        :param port: Port of the telegraf client. Defaults to PORT., defaults to TELEGRAF_PORT
        :type port: int, optional
        :param tags: Tags for telegraf. Defaults to None., defaults None
        :type tags: Any, optional
        """
        super().__init__(host, port, tags)

        # Creating the socket immediately should be safe because it's UDP
        self._connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, data: str) -> Any:
        """Send the given data to the socket via UDP.

        :param data: Data to be sent to telegraf
        :type data: str
        :return: Bytes written to the socket / None
        :rtype: Any
        """
        address = (self.host, self.port)
        return self._connection.sendto(data.encode('utf-8'), address)

    def close(self) -> None:
        """Close the socket connection with telegraf."""
        return self._connection.close()
