"""Http client to connect to Telegraf over http."""
import os
from typing import Any

from requests_futures.sessions import FuturesSession

from sac_telegraf.clients.base import BaseClient
from sac_telegraf.constants import (DEFAULT_HOST, DEFAULT_PORT,
                                    TELEGRAPH_WRITE_URL, WRITE_URL)


class HttpClient(BaseClient):
    """HTTP telegraf client."""

    _session: FuturesSession = None

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, tags: Any = None) -> None:
        """Initialise Http client for telegraf.

        :param host: Host of telegraf client. Defaults to HOST., defaults to TELEGRAF_HOST
        :type host: str, optional
        :param port: Port of the telegraf client. Defaults to PORT., defaults to TELEGRAF_PORT
        :type port: int, optional
        :param tags: Tags for telegraf. Defaults to None., defaults to None
        :type tags: Any, optional
        :raises ImportError: if the requests_futures module is not installed raise error
        """
        super().__init__(host, port, tags)

        # the default url path for writing metrics to Telegraf is /write
        telegraf_url = os.environ.get(WRITE_URL, TELEGRAPH_WRITE_URL)
        self.url = telegraf_url.format(host=self.host, port=self.port)

        # create a session to reuse the TCP socket when possible
        self._session = FuturesSession()

    def send(self, data: str) -> Any:
        """Send the data in a separate thread via HTTP POST.

        HTTP introduces some overhead, so to avoid blocking the main thread,
        this issues the request in the background.

        :param data: data to be sent to telegraf
        :type data: str
        :return: Http success / error response codes
        :rtype: Any
        """
        return self._session.post(url=self.url, data=data)

    def close(self) -> None:
        """Close the http connection with telegraf."""
        return self._session.close()
