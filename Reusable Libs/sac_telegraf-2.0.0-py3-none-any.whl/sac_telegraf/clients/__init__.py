"""Clients to access telegraf and send the measurements data.

There are two main clients:
1. Http client
2. Socket client
"""
