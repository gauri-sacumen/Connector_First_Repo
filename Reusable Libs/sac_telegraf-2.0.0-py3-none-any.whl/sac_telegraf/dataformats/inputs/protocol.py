"""InfluxDB line protocol input data format to send data to telegraf.

InfluxDB uses line protocol to write data points.
It is a text-based format that provides the measurement, tag set, field set, and timestamp of a data point.
"""
from typing import Any, Dict

from sac_telegraf.constants import VALUE
from sac_telegraf.utils import format_string, format_value


class Line:
    """InfluxDB line protocol implementation to represent metrics to store in influxdb."""

    measurement: str = ''
    values: Dict[str, Any] = {}
    tags: Dict[str, Any] = {}
    timestamp: int = 0

    def __init__(self, measurement: str, values: Dict[str, Any], tags: Any = None, timestamp: int = 0) -> None:
        """Initiate line protocol.

        :param measurement: Measurement to be added
        :type measurement: str
        :param values: Measurement values to be added
        :type values: Dict[str, Any]
        :param tags: Tags to include for the measurement, defaults to None
        :type tags: Any, optional
        :param timestamp: Timestamp of the record, defaults to None
        :type timestamp: int, optional
        """
        # Name of the actual mearurement
        self.measurement = measurement
        # Single value or dictionary of key:value pairs
        self.values = values
        # Dictionary of tags if any
        self.tags = tags or {}
        # User provided timestamp if any
        self.timestamp = timestamp

    def get_measurement(self) -> str:
        """Get the measurement as per required by line protocol.

        Formats and escapes measurement name that can be rendered to line protocol

        :return: measurements as per line protocol standard
        :rtype: str
        """
        return format_string(self.measurement)

    def get_values(self) -> str:
        """Get the values as per the requirement by line protocol.

        Return an escaped string of comma separated value_name: value pairs

        :return: comma separated key=value pairs
        :rtype: str
        """
        # Handle primitive values here and implicitly convert them to a dict because
        # it allows the API to be simpler.

        # Also influxDB mandates that each value also has a name so the default name
        # for any non-dict value is "value"
        metric_values = {VALUE: self.values} if not isinstance(self.values, dict) else self.values

        # Sort the values in lexicographically by value name
        sorted_values = sorted(metric_values.items())

        # Remove non values
        values = [(key, value) for key, value in sorted_values if value is not None]

        value_lst = ["{key}={value}".format(key=format_string(key), value=format_value(value)) for key, value in values]

        return ','.join(value_lst)

    def get_tags(self) -> str:
        """Get the formatted tags as per required by line protocol.

        Return an escaped string of comma separated key: value pairs

        Tags should be sorted by key before being sent for best performance.
        The sort should match that from the Go bytes.

        :return: comma separated key=value pairs
        :rtype: str
        """
        # Sort the tags in lexicographically by tag name
        sorted_tags = sorted(self.tags.items())

        # Render and escape each tag string
        tags = ["{key}={value}".format(key=format_string(key), value=format_value(value)) for key, value in sorted_tags]

        return ','.join(tags)

    def get_timestamp(self) -> str:
        """Get the formatted timestamp as per line protocol.

        Formats timestamp so it can be rendered to line protocol

        :return: string representation of the timestamp
        :rtype: str
        """
        return str(self.timestamp) if self.timestamp else ''

    def to_line_protocol(self) -> str:
        """Convert the given metrics as a single line of InfluxDB line protocol.

        :return: metrics representation as per line protocol
        :rtype: str
        """
        # Get measurements
        measurements = self.get_measurement()

        # Get values
        values = self.get_values()

        # Get tags
        tags = self.get_tags()
        tags = tags if tags else ''

        # Get timestamp
        timestamp = self.get_timestamp()

        line_protocol = f"{measurements},{tags} {values}"
        if timestamp:
            line_protocol = f"{line_protocol} {timestamp}"

        return line_protocol
