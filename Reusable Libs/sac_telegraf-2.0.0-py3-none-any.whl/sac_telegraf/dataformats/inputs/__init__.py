"""Input dataformats to send data to telegraf."""
