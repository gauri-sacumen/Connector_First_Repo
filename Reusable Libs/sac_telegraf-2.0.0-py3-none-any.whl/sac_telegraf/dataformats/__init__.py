"""Dataformats to send or retrieve data from telegraf.

Telegraf allows to read and write in multiple data formats.
Based on this, the data formats are divided in two main categories,

1. Input data formats.
2. Output data formats.

Input data formats are of following types:

1. influxDB line protocol [Implemented]
2. Json
3. XML
4. CSV
5. Value
6. Collectd
7. Dropwizard
8. Graphite
9. Grok
10. Logfmt
11. Nagios
12. Prometheus Remote write
13. Wavefront

Output data formats as of following types:

1. InfluxDB line protocol
2. Carbon2
3. Graphite
4. Json
5. MessagePack
6. ServiceNow Metrics
7. SplunkMetric

NOTE: From above list, InfluxDB line protocol input data format is implemented as of now.
Others will be implemented in the future as need arises.
"""
