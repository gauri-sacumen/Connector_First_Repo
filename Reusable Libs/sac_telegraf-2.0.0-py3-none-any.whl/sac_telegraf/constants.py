"""Constants for sac_telegraf."""
WRITE_URL = "TELEGRAPH_WRITE_URL"
VALUE = "value"

# Default values
DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8094

TELEGRAPH_WRITE_URL = "http://{host}:{port}/write"
