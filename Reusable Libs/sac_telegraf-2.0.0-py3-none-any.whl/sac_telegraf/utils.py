"""Utils for use in telegraf connector."""
from typing import Any


def format_string(key: str) -> str:
    r"""Format either measurement names, tag names or tag values.

    Measurement name and any optional tags separated by commas.

    Measurement names, tag keys, and tag values must escape any spaces, commas or equal signs using a backslash (\).
    For example: \ and \,.

    All tag values are stored as strings and should not be surrounded in quotes.

    :param key: String to be formatted
    :type key: str
    :return: Formatted string as per the rules of telegraf line protocol
    :rtype: str
    """
    key = key.strip()
    key = key.replace(' ', r'\ ')
    key = key.replace(',', r'\,')
    key = key.replace('=', r'\=')
    return key


def format_value(value: Any) -> Any:
    r"""Format values based on whether they are numeric values or boolean or strings.

    The value can be any of the four primitive types as string, integer, float or bool which needs to be formatted.

    Integers are numeric values that do not include a decimal and are followed by a trailing i when inserted
    (e.g. 1i, 345i, 2015i, -10i). Note that all values must have a trailing i.

    If they do not they will be written as floats.

    Floats are numeric values that are not followed by a trailing i. (e.g. 1, 1.0, -3.14, 6.0e5, 10).

    Boolean values indicate true or false. Valid boolean strings for line protocol are
    (t, T, true, True, TRUE, f, F, false, False and FALSE).

    Strings are text values. All string field values must be surrounded in double-quotes ".
    If the string contains a double-quote, the double-quote must be escaped with a backslash, e.g. \".

    :param value: The value to be converted
    :type value: Any
    :return: string representaiton of the value as per required for telegraf line protocols
    :rtype: Any
    """
    if isinstance(value, str):
        value = value.replace('"', '\"')
        value = f'"{value}"'
    elif isinstance(value, bool):
        value = str(value)
    elif isinstance(value, int):
        value = f"{value}i"
    elif isinstance(value, float):
        value = str(value)

    return value


def is_repr_of_int(string: str) -> bool:
    """Check if provided string is an integer representation of integer number as per line protocol.

    Returns True for strings like: '123i', '+123i', '-123i'

    :param string: String to be evaluated to check if it is integer representation
    :type string: str
    :return: True if the string is integer representation of integer number as per the line protocol else False
    :rtype: bool
    """
    start = int(string.startswith('+') or string.startswith('-'))

    return string[start: -1].isdigit() and string.endswith('i')
